Create a folder in local pc
Right click on folder and open Git Bash
 git clone https://github.com/samplearjun/java1.git

Folder has a .java file
git add *.java
git add helloworld.java
git commit -m "first commit"
Git push
Enter username and password
