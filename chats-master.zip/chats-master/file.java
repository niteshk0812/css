public class helloworld
{
  public static void main(String[] args) {
        System.out.println("Hello World again !!! ");
    
        System.out.println("New line added today ... 19th June 2018");
 //creating object
  }
}
public class helloworld
{
  public static void main(String[] args) {
        System.out.println("Hello World again !!! ");
    
        System.out.println("New line added today ... 19th June 2018");
 //creating object
  }
}
