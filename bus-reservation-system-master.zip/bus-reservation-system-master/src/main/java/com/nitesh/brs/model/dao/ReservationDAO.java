package com.nitesh.brs.model.dao;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.nitesh.brs.model.bean.ReservationBean;

//CRUD operations
public interface ReservationDAO {
   
	public List<ReservationBean> findByPid(int pid) throws EmptyResultDataAccessException;
  
}