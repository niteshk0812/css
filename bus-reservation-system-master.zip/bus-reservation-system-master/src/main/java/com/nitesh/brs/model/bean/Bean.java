package com.nitesh.brs.model.bean;

import com.nitesh.brs.model.Model;

/**
 * @author <a href="http://shivajivarma.com" target="_blank">Shivaji Varma</a>
 */
public interface Bean extends Model{}