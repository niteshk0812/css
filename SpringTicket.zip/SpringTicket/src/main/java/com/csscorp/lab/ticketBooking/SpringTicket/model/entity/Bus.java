package com.csscorp.lab.ticketBooking.SpringTicket.model.entity;

public class Bus {

}
