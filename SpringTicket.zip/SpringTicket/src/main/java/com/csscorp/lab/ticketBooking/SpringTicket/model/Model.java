package com.csscorp.lab.ticketBooking.SpringTicket.model;

public interface Model {

}
